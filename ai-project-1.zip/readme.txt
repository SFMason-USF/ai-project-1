A* Search Program, Intro to AI Project 1

Prerequisites
-Python 3.6

Running
-Run "ai-project-1.py" with python 3.6
-Run with no arguments to see arguments specifications

Author:
Spenser Mason